Botan 1.10.0, 2011-06-20
http://botan.randombit.net/

Botan is a C++ class library for performing a wide variety of
cryptographic operations. It is released under the 2 clause BSD
license; see doc/license.txt for the specifics. You can file bugs in
Bugzilla (http://bugs.randombit.net/) or by sending a report to the
botan-devel mailing list. More information about the mailing list is
at http://lists.randombit.net/mailman/listinfo/botan-devel/

You can find documentation online at http://botan.randombit.net/docs
and http://botan.randombit.net/doxygen. A set of example programs can
be found in the examples directory.

Jack Lloyd (lloyd@randombit.net)
